function setImgCover(e) {
	e.each(function() {
		$(this).parent().css({
			'background-image': 'url("'+$(this).attr('src')+'")',
			'background-repeat': 'no-repeat',
			'background-position': 'center center',
			'background-size': 'cover'
		});
	});
}
function setImgContain(e) {
	e.each(function() {
		$(this).parent().css({
			'background-image': 'url("'+$(this).attr('src')+'")',
			'background-repeat': 'no-repeat',
			'background-position': 'center center',
			'background-size': 'contain'
		});
	});
}
function setRatio() {
	$('[data-ratio]').each(function() {
		var t = $(this).find('.scale');
		t.css('cssText',`height: ${t.outerWidth()*$(this).attr('data-ratio')}px !important`)
		//t.outerHeight(t.outerWidth()*$(this).attr('data-ratio'));
	});
}



$(document).on('update_blocks',function () {

    setImgCover($('.img-cover'));
    setImgContain($('.img-contain'));
    setRatio();

});



$(document).ready(function () {


    setImgCover($('.img-cover'));
    setImgContain($('.img-contain'));


    var isMobile = false;
    var justSwitched = false;
    function detectDevice() {
        var temp = isMobile;
        if ( Modernizr.mq('(max-width:767px)') ) {
            isMobile = true;
        } else {
            isMobile = false;
        }
        if ( temp == isMobile ) {
            justSwitched = false;
        } else {
            justSwitched = true;
        }
    }
    function startApp() {
        detectDevice();
        if ( justSwitched ) {
            if ( isMobile ) {
                $('.nav').detach().prependTo($('.panel__row'));
                $('.footer__nav').detach().insertBefore($('.footer__about'));
                $('.header__row').append('<span class="menu-open"><i></i></span>');
            } else {
                $('.nav').detach().insertAfter($('.header--logo'));
                $('.footer__nav').detach().insertAfter($('.footer__about'));
                if ( $('.menu-open').hasClass('is-active') ) {
                    menuClose();
                }
                $('.menu-open').remove();
            }
        }
        setRatio();
    }
    startApp();
    var lastWidth = $(window).width();
    $(window).on('resize', _.debounce(function() {
        if ( $(window).width() != lastWidth ) {
            startApp();
            lastWidth = $(window).width();
        }
    }, 100));
		$('.intro_main').slick({
			slidesToScroll: 1,
			slidesToShow: 1,
			arrows: true,
			dots: true,
			infinite: true,
			cssEase: 'ease',
			speed: 800,
			autoplay: true,
			autoplaySpeed: 5000
		});
		$('.intro_persons').slick({
			slidesToScroll: 1,
			slidesToShow: 1,
			arrows: true,
			dots: true,
			infinite: true,
			cssEase: 'ease',
			speed: 800,
			autoplay: true,
			autoplaySpeed: 5000,
			fade: true
		});
		$('.intro_news').slick({
			slidesToScroll: 1,
			slidesToShow: 1,
			arrows: true,
			dots: true,
			infinite: true,
			cssEase: 'ease',
			speed: 800,
			autoplay: false,
			autoplaySpeed: 5000,
			fade: true
		});
    $('[data-open]').on('click', function(e) {
        e.preventDefault();
        $(this).addClass('is-active');
        var t = $('[data-target="'+$(this).attr('data-open')+'"]');
        t.siblings('[data-target]').removeClass('is-opened is-active');
        $('.fade-bg').addClass('is-opened');
        t.addClass('is-opened');
        var h = $(window).scrollTop()+($(window).height()-t.outerHeight())/2;
        if ( !isMobile ) {
            var diff = 30;
        } else {
            var diff = 15;
        }
        if ( h < $(window).scrollTop()+(diff*2) ) {
            h = $(window).scrollTop()+diff;
        }
        t.css({
            'top': h+'px'
        }).addClass('is-active').siblings('[data-target]').removeClass('is-active');
    });
    $('[data-target] .modal--close, .fade-bg').on('click', function(e) {
        e.preventDefault();
        $('[data-target], .fade-bg').removeClass('is-opened');
        $('[data-open]').removeClass('is-active');
        if ( $('.menu-open').hasClass('is-active') ) {
            menuClose();
        }
    });
	$('input[type="checkbox"]').uniform();
    function menuOpen() {
        $('.panel, .fade-bg').addClass('is-opened');
        $('body').addClass('is-locked');
        $('.menu-open').addClass('is-active');
        $('.header').addClass('is-overlay');
    }
    function menuClose() {
        $('.panel, .fade-bg').removeClass('is-opened');
        $('body').removeClass('is-locked');
        $('.menu-open').removeClass('is-active');
        setTimeout(function() {
            $('.header').removeClass('is-overlay');
        }, 200);
    }
    $(document).on('click', '.menu-open', function () {
        if ( !$(this).hasClass('is-active') ) {
            menuOpen();
        } else {
            menuClose();
        }
    });

    if ( $('.circle-progress').length ) {
        $(window).on('scroll', function() {
            $('.circle-progress').each(function() {
                if ( $(this).attr('data-complete') == undefined & $(document).scrollTop()>$(this).offset().top-$(window).height() ) {
                    $(this).circleProgress({
                        value: $(this).attr('data-value'),
                        startAngle: Math.PI/4*$(this).attr('data-start'),
                        size: 166,
                        thickness: 5,
                        fill: '#852a34',
                        emptyFill: 'transparent'
                    }).on('circle-animation-progress', function(event, progress, stepValue) {
                        $(this).find('p').html((stepValue*100).toFixed(0)+'%');
                    }).attr('data-complete',true);
                }
            });
        });
    }
    $('[data-scroll] a').on('click', function(e) {

        e.preventDefault();
        var t = $('[data-scroll-to="'+$(this).attr('href')+'"]');
        $('html, body').stop().animate({
            scrollTop: t.position().top
        }, 1000, 'easeOutCubic');
        if ( $('.menu-open').hasClass('is-active') ) {
            menuClose();
        }

    });

    $('input, textarea').each(function() {
        $(this).data('holder', $(this).attr('placeholder'));
        $(this).focusin(function() {
            $(this).attr('placeholder', '');
        });
        $(this).focusout(function() {
            $(this).attr('placeholder', $(this).data('holder'));
        });
    });


    $(".js-ajax-form").each(function () {
        var element = $(this);

        var res = element.find('.result');

        element.submit(function (event) {
            event.preventDefault(event);

            var form = $(this);
            var formData = new FormData($(form)[0]);
            var success_text = form.data('success-text');
            var error_text = form.data('error-text');
            var exit_text = form.data('exit-text');

            res.html('');

            $.ajax({
                url: form.attr('action'),
                type: 'post',
                processData: false,
                contentType: false,
                data: formData,
                dataType: 'json',
                success: function (response) {

                    if (response.hasOwnProperty('success') && response.success) {
                        if(!!exit_text && exit_text.length > 0 ){

                            form.html(alert_exit(exit_text));

                        }else{
                            res.html(alert_success(success_text));
                        }


                        //form[0].reset();
                        form.trigger('reset');
                    }
                    if (response.hasOwnProperty('error') && response.error) {
                        res.html(alert_error(error_text));
                    }

                    return false;
                }
            });
        });

    });


    $('input[name="phone"]').each(function (index,el) {

        $(el).mask("+7(999)999-99-99",{placeholder:"_",autoclear: false});

    })

});


$(window).load(function() {
    $('.event-intro__row .person, .event-intro__text').addClass('is-animated');

    // Книга Хаки
    var $book = $('.js-book');
    if( $book.length && $.fn.slick ){

        $book.on("init", function(event, slick){
            $(".js-pdf-book-pager").text(parseInt(slick.currentSlide + 1) + ' / ' + slick.slideCount);
        });

        $book.on("afterChange", function(event, slick, currentSlide){
            $(".js-pdf-book-pager").text(parseInt(slick.currentSlide + 1) + ' / ' + slick.slideCount);
        });

        $book.slick({
            lazyLoad: 'ondemand',
            slidesToShow: 1,
            slidesToScroll: 1,
        });
    }
});



alert_exit = function (add_str) {
    var str = '<div class="modal-exit-text">'+add_str+'</div>';
    return str;
};


alert_success = function (add_str) {
    var str = '<div class="alert alert-success">'+add_str+'</div>';
    return str;
};

alert_error =  function (add_str) {
    var str = '<div class="alert alert-danger">'+add_str+'</div>';
    return str;
};



